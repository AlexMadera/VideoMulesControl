package Models;

import Queries.PlayerQueries;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class FillPlayersList {
    /**
    public ArrayList<Videos> players = new ArrayList<>();

    public static void FillList (String Type) throws Exception{
        String videoQuery = PlayerQueries.PlayersQuery(Type);
        ResultSet rs = stmt.executeQuery(videoQuery);
        while(rs.next()){
            System.out.println(rs.getString("player_name"));
        }
    }**/
}
