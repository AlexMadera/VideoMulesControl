**README.md**

The Mules Video Player is an application that provides University of Central Missouri baseball players a centralized location to watch and share game videos. By viewing videos of both UCM and opponent players, our baseball players can improve plays and form new strategies.


Created by Alex Madera and Andrew Purchase for our Spring 2021 Advanced Java Applications class. 

Demo of project here:
https://www.youtube.com/watch?v=pG07bNMD_Ik
